---
title: SLRE - Super Light RegEx
color: '#AAA496'
repo: https://github.com/cesanta/slre
items:
  - { type: file, name: overview.md }
  - { type: file, name: syntax.md }
  - { type: file, name: api.md }
  - { type: file, name: examples.md }
  - { type: file, name: license.md }
---
