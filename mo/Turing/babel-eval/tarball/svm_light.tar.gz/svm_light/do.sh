make
./svm_learn train.dat model
